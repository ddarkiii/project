-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 04, 2019 at 08:49 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shopping`
--

-- --------------------------------------------------------

--
-- Table structure for table `attributes`
--

CREATE TABLE `attributes` (
  `attribute_id` int(11) NOT NULL,
  `name` varchar(200) DEFAULT NULL,
  `value` varchar(200) NOT NULL,
  `attribute_value_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attributes`
--

INSERT INTO `attributes` (`attribute_id`, `name`, `value`, `attribute_value_id`, `product_id`) VALUES
(1, 'Size', 'S', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL,
  `name` varchar(100) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `description` varchar(200) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `department_id` int(11) NOT NULL,
  `page` int(11) NOT NULL DEFAULT '1',
  `product_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `name`, `description`, `department_id`, `page`, `product_id`) VALUES
(1, 'French', 'The French', 1, 1, 1),
(2, 'German', 'The German', 2, 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `customer_id` int(11) NOT NULL,
  `name` varchar(100) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `email` varchar(200) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `address_1` varchar(200) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `address_2` varchar(200) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `city` varchar(200) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `region` varchar(200) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `postal_code` varchar(200) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `country` varchar(200) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `shipping_region_id` int(11) NOT NULL,
  `day_phone` varchar(200) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `eve_phone` varchar(200) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `mob_phone` varchar(200) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `credit_card` varchar(200) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `password` varchar(200) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `access_token` varchar(200) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customer_id`, `name`, `email`, `address_1`, `address_2`, `city`, `region`, `postal_code`, `country`, `shipping_region_id`, `day_phone`, `eve_phone`, `mob_phone`, `credit_card`, `password`, `access_token`) VALUES
(1, 'Harry', 'harry@hotmail.com', 'Sacramento', 'Vancouver', 'Atlanta', 'Indiana', '45689', 'USA', 2, '+3891123456', '+3891113567', '+391234567', 'xxxxxxx43545345', '', ''),
(2, 'Harry', 'harry@hotmail.com', 'Texas', 'Oklahoma', 'Colorado', 'Texas', '23456', 'USA', 2, '+345576756', '+12324234234234', '+2394839248', 'xxxxxx122234', '', ''),
(3, 'Larry', 'larry@hotmail.com', 'San Antonio', 'Florida', 'Brooklyn', 'Brooklyn', '34567', 'USA', 3, '+321456908', '+389124567', '+2345890', 'xxxxcvcvcvc12345', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `customers_users`
--

CREATE TABLE `customers_users` (
  `user_id` int(11) NOT NULL,
  `email` varchar(200) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `password` varchar(200) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `customer_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `department_id` int(11) NOT NULL,
  `name` varchar(200) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `product_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`department_id`, `name`, `description`, `product_id`) VALUES
(1, 'Regional', 'Proud of your country?Wear a T-shirt with a national symbol stamp!', 1),
(2, 'Reg', 'Proud', 2);

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `order_id` int(11) NOT NULL,
  `cost_id` varchar(100) NOT NULL,
  `product_id` int(11) NOT NULL,
  `tax_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `orderId` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `attributes` varchar(200) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `product_name` varchar(200) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `quantity` int(11) NOT NULL,
  `unitcost` varchar(100) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `subtotal` varchar(100) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `cost_id` varchar(100) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `shipping_id` int(11) NOT NULL,
  `tax_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`orderId`, `product_id`, `attributes`, `product_name`, `quantity`, `unitcost`, `subtotal`, `cost_id`, `shipping_id`, `tax_id`, `customer_id`) VALUES
(1, 1, 'LG Red', 'Are d\'Triemple', 1, '14.99', '14.99', '1', 1, 1, 1),
(2, 1, '', '', 0, '', '', '1', 0, 1, 2),
(3, 2, '', '', 0, '', '', '2', 0, 2, 3),
(4, 2, 'LG', 'TV', 1, '15.00$', '15.00$', '2', 0, 2, 4),
(5, 3, 'LG', 'TV', 2, '15.00$', '15.00$', '3', 1, 3, 5),
(6, 4, 'Samsung', 'TV', 3, '16.00$', '16.00$', '4', 1, 4, 6),
(7, 5, 'Philips', 'TV', 5, '17.00$', '17.00$', '5', 2, 5, 7);

-- --------------------------------------------------------

--
-- Table structure for table `orders_shortdetail`
--

CREATE TABLE `orders_shortdetail` (
  `order_id` int(11) NOT NULL,
  `total_amount` int(11) NOT NULL,
  `Created_on` varchar(100) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `shipped_on` varchar(100) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `status` varchar(100) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `name` varchar(100) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders_shortdetail`
--

INSERT INTO `orders_shortdetail` (`order_id`, `total_amount`, `Created_on`, `shipped_on`, `status`, `name`) VALUES
(1, 1, '', '', 'paid', 'Test');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` varchar(200) NOT NULL,
  `price` varchar(100) NOT NULL,
  `discounted_price` varchar(100) NOT NULL,
  `thrumbail` varchar(200) NOT NULL,
  `page` int(11) NOT NULL DEFAULT '1',
  `image` varchar(200) DEFAULT NULL,
  `image2` varchar(200) DEFAULT NULL,
  `display` int(11) DEFAULT NULL,
  `department_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `name`, `description`, `price`, `discounted_price`, `thrumbail`, `page`, `image`, `image2`, `display`, `department_id`, `category_id`) VALUES
(1, 'Charters Cathedral', 'The fur Merchaunts', '16.95', '15.95', 'cathedral-thrumbail.gif', 1, NULL, NULL, 0, 1, 1),
(2, 'Cathedral', 'The cath fur Merchaunts', '17.95', '15.95', 'cathedral.gif', 1, 'cath.gif', 'cath1.gif', 0, 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `review`
--

CREATE TABLE `review` (
  `review_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `review` varchar(200) NOT NULL,
  `rating` int(11) NOT NULL,
  `created_on` datetime NOT NULL,
  `product_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `review`
--

INSERT INTO `review` (`review_id`, `name`, `review`, `rating`, `created_on`, `product_id`) VALUES
(1, 'Eder Temeria', 'That good proud', 5, '2019-05-07 00:00:00', 1),
(2, 'Deny Rose', 'That is good', 6, '0000-00-00 00:00:00', 2),
(3, 'Deny Rose', 'That is good', 6, '2018-10-22 13:34:00', 3);

-- --------------------------------------------------------

--
-- Table structure for table `shipping`
--

CREATE TABLE `shipping` (
  `shipping_id` int(11) NOT NULL,
  `shipping_type` varchar(200) NOT NULL,
  `shipping_cost` varchar(200) NOT NULL,
  `shipping_region_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shipping`
--

INSERT INTO `shipping` (`shipping_id`, `shipping_type`, `shipping_cost`, `shipping_region_id`) VALUES
(1, 'Next Day Delivery($20)', '20.00', 2),
(2, 'Delivery', '15', 5),
(3, 'Deliver', '20', 6),
(4, 'Deliveri', '25', 2);

-- --------------------------------------------------------

--
-- Table structure for table `shipping_regions`
--

CREATE TABLE `shipping_regions` (
  `shipping_region_id` int(11) NOT NULL,
  `shipping_region` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shipping_regions`
--

INSERT INTO `shipping_regions` (`shipping_region_id`, `shipping_region`) VALUES
(1, 'Please select');

-- --------------------------------------------------------

--
-- Table structure for table `shopping_cart`
--

CREATE TABLE `shopping_cart` (
  `cart_id` varchar(200) NOT NULL,
  `item_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `attributes` varchar(200) NOT NULL,
  `product_id` int(11) NOT NULL,
  `price` varchar(200) NOT NULL,
  `quantity` int(11) NOT NULL,
  `image` varchar(200) NOT NULL,
  `subtotal` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tax`
--

CREATE TABLE `tax` (
  `tax_id` int(11) NOT NULL,
  `tax_type` varchar(200) DEFAULT NULL,
  `tax_percentage` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tax`
--

INSERT INTO `tax` (`tax_id`, `tax_type`, `tax_percentage`) VALUES
(1, 'Sales Tax at 8,5%', '8,50');

-- --------------------------------------------------------

--
-- Table structure for table `values`
--

CREATE TABLE `values` (
  `attribute_value_id` int(11) NOT NULL,
  `values` varchar(200) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `attribute_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `values`
--

INSERT INTO `values` (`attribute_value_id`, `values`, `attribute_id`) VALUES
(1, 'S', 1);

-- --------------------------------------------------------

--
-- Table structure for table `vl`
--

CREATE TABLE `vl` (
  `attribute_value_id` int(11) NOT NULL,
  `vl` varchar(200) NOT NULL,
  `attribute_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vl`
--

INSERT INTO `vl` (`attribute_value_id`, `vl`, `attribute_id`, `product_id`) VALUES
(1, 'S', 1, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attributes`
--
ALTER TABLE `attributes`
  ADD PRIMARY KEY (`attribute_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `customers_users`
--
ALTER TABLE `customers_users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`department_id`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`orderId`);

--
-- Indexes for table `orders_shortdetail`
--
ALTER TABLE `orders_shortdetail`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `review`
--
ALTER TABLE `review`
  ADD PRIMARY KEY (`review_id`);

--
-- Indexes for table `shipping`
--
ALTER TABLE `shipping`
  ADD PRIMARY KEY (`shipping_id`);

--
-- Indexes for table `shipping_regions`
--
ALTER TABLE `shipping_regions`
  ADD PRIMARY KEY (`shipping_region_id`);

--
-- Indexes for table `shopping_cart`
--
ALTER TABLE `shopping_cart`
  ADD PRIMARY KEY (`cart_id`);

--
-- Indexes for table `tax`
--
ALTER TABLE `tax`
  ADD PRIMARY KEY (`tax_id`);

--
-- Indexes for table `values`
--
ALTER TABLE `values`
  ADD PRIMARY KEY (`attribute_value_id`);

--
-- Indexes for table `vl`
--
ALTER TABLE `vl`
  ADD PRIMARY KEY (`attribute_value_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attributes`
--
ALTER TABLE `attributes`
  MODIFY `attribute_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `customers_users`
--
ALTER TABLE `customers_users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `department_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `orderId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `orders_shortdetail`
--
ALTER TABLE `orders_shortdetail`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `review`
--
ALTER TABLE `review`
  MODIFY `review_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `shipping`
--
ALTER TABLE `shipping`
  MODIFY `shipping_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `shipping_regions`
--
ALTER TABLE `shipping_regions`
  MODIFY `shipping_region_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tax`
--
ALTER TABLE `tax`
  MODIFY `tax_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `values`
--
ALTER TABLE `values`
  MODIFY `attribute_value_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `vl`
--
ALTER TABLE `vl`
  MODIFY `attribute_value_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
