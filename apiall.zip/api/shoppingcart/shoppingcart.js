﻿const express=require('express');
const bodyParser=require('body-parser');
const app=express();
const mysql=require('mysql');
const uniqid=require('uniqid');

app.use(bodyParser.json());
const conn=mysql.createConnection({
host: 'localhost',
user: 'root',
password: '',
database: 'shopping'
});

conn.connect((err) =>{
if(err) throw err;
console.log("You are connected to database!");
});

//get shopping cart cart_id
app.get('/shoppingcart/:cart_id',(req,res)=>{
let sql="SELECT * FROM shopping_cart WHERE cart_id="+req.params.cart_id;
let query=conn.query(sql,(err,results)=>{
if(err){
res.status(400).send(JSON.stringify({"code":"USR_02","message":"The field example is empty","field":"example","status":"500"}));
}
else{
res.status(200).send(JSON.stringify(results));
}
});
});
// /shoppingcart/totalAmount/cart_id provjeriti formulu računanja
app.get('/shoppingcart/totalAmount/:cart_id',(req,res)=>{
let sql="SELECT count(subtotal) as total_amount FROM shoppingcart WHERE cart_id="+req.params.cart_id;
let query=conn.query(sql,(err,results)=>{
if(err){
res.status(400).send(JSON.stringify({"code":"USR_02","message":"The field example is empty","field":"example","status":"500"}));
}
else{
res.send(JSON.stringify({"status":200,"error":null,"total_amount":total_amount}));
}
});
});
// /shoppingcart/generateUniqueId
app.get('/shoppingcart/generateUniqueId',(req,res)=>{
//let cart_id=uniqid();
let sql="SELECT cart_id FROM shopping_cart WHERE cart_id="+req.params.cart_id;
let query=conn.query(sql,(err,results)=>{
if(err){
res.status(400).send(JSON.stringify({"code":"USR_02","message":"The field example is empty","field":"example","status":"500"}));
}
else{
res.status(200).send(JSON.stringify({"cart_id":results}));
}
});
});

//get /shopping_cart/moveTocart/item_id
app.get('/shoppingcart/moveTocart/:item_id',(req,res)=>{
let sql="SELECT * FROM shopping_cart WHERE item_id="+req.params.item_id;
let query=conn.query(sql,(err,results)=>{
if(err){
res.status(400).send(JSON.stringify({"code":"USR_02","message":"The field example is empty","field":"example","status":"500"}));
}
else{
res.send(JSON.stringify({"status":200,"error":null,"response":"No data"}));
}
});
});
//get /shopping_cart/getSaved/cart_id
app.get('/shoppingcart/getSaved/:cart_id',(req,res)=>{
let sql="SELECT item_id,name,attributes,price FROM shopping_cart WHERE cart_id="+req.params.cart_id;
let query=conn.query(sql,(err,results)=>{
if(err){
res.status(400).send(JSON.stringify({"code":"USR_02","message":"The field example is empty","field":"example","status":"500"}));
}
else{
res.send(JSON.stringify({"status":200,"error":null,"results":results}));
}
});
});
//get /shopping_cart/SaveToLater/item_id
app.get('/shoppingcart/SaveToLater/:item_id',(req,res)=>{
let sql="SELECT * FROM shopping_cart WHERE item_id="+req.params.item_id;
let query=conn.query(sql,(err,results)=>{
if(err){
res.status(400).send(JSON.stringify({"code":"USR_02","message":"The field example is empty","field":"example","status":"500"}));
}
else{
res.send(JSON.stringify({"status":200,"error":null,"response":"No data"}));
}
});
});
//add new shopping cart
app.post('/shoppingcart/add',(req, res) => {
	let cartid=uniqid();
  let data = {cart_id: cartid, item_id: req.body.item_id, name: req.body.name, attributes: req.body.attributes, product_id: req.body.product_id, price: req.body.price, quantity: req.body.quantity, image: req.body.image, subtotal: req.body.subtotal};
  let sql = "INSERT INTO shopping_cart SET ?";
  let query = conn.query(sql, data,(err, results) => {
if(err){
res.status(400).send(JSON.stringify({"code":"USR_02","message":"The field example is empty","field":"example","status":"500"}));
}	
else{
    res.send(JSON.stringify({"status": 200, "error": null, "response": results}));
}
  });
});
//put /shoppingcart/update/item_id
app.put('/shoppingcart/update/:item_id',(req, res) => {
  let sql = "UPDATE shopping_cart SET cart_id='"+req.body.cart_id+"', item_id='"+req.body.item_id+"', name='"+req.body.name+"', attributes='"+req.body.attributes+"', product_id='"+req.body.product_id+"', price='"+req.body.price+"', quantity='"+req.body.quantity+"', image='"+req.body.image+"', subtotal='"+req.body.subtotal+"' WHERE item_id="+req.params.item_id;
  let query = conn.query(sql, (err, results) => {
	  if(err){
res.status(400).send(JSON.stringify({"code":"USR_02","message":"The field example is empty","field":"example","status":"500"}));
}
    if(!err) {
    res.send(JSON.stringify({"status": 200, "error": null, "results": results}));
	}
  });
});

//Delete /shoppingcart/empty/cart_id
app.delete('/shoppingcart/empty/:cart_id',(req, res) => {
  let sql = "DELETE FROM shopping_cart WHERE cart_id="+req.params.cart_id+"";
  let query = conn.query(sql, (err, results) => {
   	  if(err){
res.status(400).send(JSON.stringify({"code":"USR_02","message":"The field example is empty","field":"example","status":"500"}));
}
	if(!err){
      res.send(JSON.stringify({"status": 200, "error": null, "response":" "}));
  }
  });
});
//DELETE /shoppingcart/removeProduct/item_id
app.delete('/shoppingcart/removeProduct/:item_id',(req, res) => {
  let sql = "DELETE FROM shopping_cart WHERE item_id="+req.params.item_id+"";
  let query = conn.query(sql, (err, results) => {
  	  if(err){
res.status(400).send(JSON.stringify({"code":"USR_02","message":"The field example is empty","field":"example","status":"500"}));
}
	if(!err){
      res.send(JSON.stringify({"status": 200, "error": null, "response":"No data" }));
  }
  });
});
 
app.listen(3000,() =>{
console.log('Server started on port 3000...');
});
//sve radi get za item_id ,put radi add dodati novi radi delete za item_id radi jedino ne rade get i delete za cart_id