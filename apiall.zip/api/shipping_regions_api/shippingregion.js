﻿const express=require('express');
const bodyParser=require('body-parser');
const app=express();
const mysql=require('mysql');

app.use(bodyParser.json());
const conn=mysql.createConnection({
host: 'localhost',
user: 'root',
password: '',
database: 'shopping'
});

conn.connect((err) =>{
if(err) throw err;
console.log("You are connected to database!");
});
app.get('/shipping/regions',(req,res)=>{
let sql="SELECT * FROM shipping_regions";
let query=conn.query(sql,(err,results)=>{
if(err){
res.status(400).send(JSON.stringify({"code":"USR_02","message":"The field example is empty","field":"example"}));

}
else{
res.status(200).send(JSON.stringify(results));

}
});
});
app.get('/shipping/regions/:shipping_region_id',(req,res)=>{
let sql="SELECT * FROM shipping WHERE shipping_region_id="+req.params.shipping_region_id;
let query=conn.query(sql,(err,results)=>{
if(err){
res.status(400).send(JSON.stringify({"code":"USR_02","message":"The field example is empty","field":"example"}));
}
else{
res.status(200).send(JSON.stringify(results));
}
});
});
app.listen(3000,() =>{
console.log('Server started on port 3000...');
});
