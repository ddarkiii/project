﻿const express=require('express');
const bodyParser=require('body-parser');
const app=express();
const mysql=require('mysql');

app.use(bodyParser.json());
const conn=mysql.createConnection({
host: 'localhost',
user: 'root',
password: '',
database: 'shopping'
});

conn.connect((err) =>{
if(err) throw err;
console.log("You are connected to database!");
});
app.get('/categories',(req,res)=>{
let sql="SELECT count(page) as count,category_id,name,description,department_id FROM category LIMIT 20";
let query=conn.query(sql,(err,results)=>{
if(err){
res.status(400).send(JSON.stringify({"code":"USR_02","message":"The field example is empty","field":"example","status":"500"}));

}
else{
	let total=results[0].count;
res.status(200).send(JSON.stringify({"count":total,"rows":results}));

}
});
});
app.get('/categories/:category_id',(req,res)=>{
let sql="SELECT category_id,name,description,department_id FROM category WHERE category_id="+req.params.category_id;
let query=conn.query(sql,(err,results)=>{
if(err){
res.status(400).send(JSON.stringify({"code":"USR_02","message":"The field example is empty","field":"example","status":"500"}));
}
else{
res.status(200).send(JSON.stringify(results));
}
});
});
app.get('/categories/inProduct/:product_id',(req,res)=>{
let sql="SELECT category_id,department_id,name FROM category  WHERE product_id="+req.params.product_id;
let query=conn.query(sql,(err,results)=>{
if(err){
res.status(400).send(JSON.stringify({"code":"USR_02","message":"The field example is empty","field":"example","status":"500"}));
}
else{
res.status(200).send(JSON.stringify(results));
}
});
});

app.get('/categories/inDepartment/:department_id',(req,res)=>{
let sql="SELECT category_id,name,description,department_id FROM category WHERE department_id="+req.params.department_id;
let query=conn.query(sql,(err,results)=>{
if(err){
res.status(400).send(JSON.stringify({"code":"USR_02","message":"The field example is empty","field":"example","status":"500"}));
}
else{
res.status(200).send(JSON.stringify(results));
}
});
});


app.listen(3000,() =>{
console.log('Server started on port 3000...');
});
