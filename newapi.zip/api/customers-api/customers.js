﻿const express=require('express');
const bodyParser=require('body-parser');
const app=express();
const mysql=require('mysql');
const jwt=require('jsonwebtoken');
 const bcrypt=require('bcryptjs');
 const SECRET_KEY="secretkey23456";
 
app.use(bodyParser.json());
const conn=mysql.createConnection({
host: 'localhost',
user: 'root',
password: '',
database: 'shopping'
});

conn.connect((err) =>{
if(err) throw err;
console.log("You are connected to database!");
});
//post customers
app.post('/customers',(req, res) => {
  let data = {customer_id: req.body.customer_id, name: req.body.name, email: req.body.email, address_1: req.body.address_1, address_2: req.body.address_2, city: req.body.city, region: req.body.region, postal_code: req.body.postal_code, country: req.body.country, shipping_region_id: req.body.shipping_region_id, day_phone: req.body.day_phone, eve_phone: req.body.eve_phone, mob_phone: req.body.mob_phone, credit_card: req.body.credit_card};
  let sql = "INSERT INTO customers SET ?";
  let expiresIn=24*60*60;
  let accessToken=jwt.sign({id: product_id},SECRET_KEY,{
  expiresIn: expiresIn
  });
  
  let query = conn.query(sql, data,(err, results) => {
if(err){
res.status(400).send(JSON.stringify({"code":"USR_02","message":"The field example is empty","field":"example","status":"500"}));
res.status(401).send(JSON.stringify({"code":"AUT-02","message":"The API is invalid.","field":"API-KEY"}));
}	
else{
    res.send(JSON.stringify({"customer": , "shema": results, "access_token": accessToken, "expiresIn": expiresIn}));
}
  });
});
//get customers with customer_id
app.get('/customers/:customer_id',(req,res)=>{
let sql="SELECT * FROM customers WHERE customer_id="+req.params.customer_id;
let query=conn.query(sql,(err,results)=>{
if(err){
res.status(400).send(JSON.stringify({"code":"USR_02","message":"The field example is empty","field":"example","status":"500"}));
res.status(401).send(JSON.stringify({"code":"AUT-02","message":"The apikey is invalid.","field":"API_KEY"}));
}
if(!err){
res.status(200).send(JSON.stringify(results));
}
});
});
//PUT /customer
app.put('/customer',(req, res) => {
  let sql = "UPDATE customers SET name='"+req.body.name+"', email='"+req.body.email+"', password='"+req.body.password+"', day_phone='"+req.body.day_phone+"', eve_phone='"+req.body.eve_phone+"', mob_phone='"+req.body.mob_phone+"',  WHERE customer_id="+req.params.customer_id;
  let query = conn.query(sql, (err, results) => {
	  if(err){
res.status(400).send(JSON.stringify({"code":"USR_02","message":"The field example is empty","field":"example","status":"500"}));
res.status(401).send(JSON.stringify({"code":"AUT-02","message":"The apikey is invalid.","field":"API_KEY"}));
}
    if(!err) {
    res.send(JSON.stringify({"status": 200, "error": null, "results": results}));
	}
  });
});
//put /customers/address
app.put('/customers/address/:customer_id',(req, res) => {
  let sql = "UPDATE customers SET address_1='"+req.body.address_1+"', address_2='"+req.body.address_2+"', city='"+req.body.city+"', region='"+req.body.region+"', postal_code='"+req.body.postal_code+"', country='"+req.body.country+"', shipping_region_id='"+req.body.shipping_region_id+"' WHERE customer_id="+req.params.customer_id;
  let query = conn.query(sql, (err, results) => {
	  if(err){
res.status(400).send(JSON.stringify({"code":"USR_02","message":"The field example is empty","field":"example","status":"500"}));
res.status(401).send(JSON.stringify({"code":"AUT-02","message":"The apikey is invalid.","field":"API_KEY"}));
}
    if(!err) {
    res.send(JSON.stringify({"status": 200, "error": null, "results": results}));
	}
  });
});
// put /customers/credit_card
app.put('/customers/creditcard/:customer_id',(req, res) => {
  let sql = "UPDATE customers SET credit_card='"+req.body.credit_card+"' WHERE customer_id="+req.params.customer_id;
  let query = conn.query(sql, (err, results) => {
	  if(err){
res.status(400).send(JSON.stringify({"code":"USR_02","message":"The field example is empty","field":"example","status":"500"}));
res.status(401).send(JSON.stringify({"code":"AUT-02","message":"The apikey is invalid.","field":"API_KEY"}));
}
    if(!err){
    res.send(JSON.stringify({"status": 200, "error": null, "response": results}));
	}
  });
});
//post customers/login
app.post('/customers/login',(req, res) => {
	let pass=bcrypt.hashSync(req.body.password);
  let data = {email: req.body.email, password: pass};
  let customer_id=req.body.customer_id;
  let sql = "INSERT INTO customers SET ?";
  
  let query = conn.query(sql, data,(err,results) => {
    if(err){
res.status(400).send(JSON.stringify({"code":"USR_02","message":"The field example is empty","field":"example","status":"500"}));
}
if(!err){
    res.status(200).send({ "customer": results});
}
  });
});
app.post('/customers/facebook',(req, res) => {
  
  let customer_id=req.body.customer_id;
  let sql = "INSERT INTO customers SET ?";
  let expiresIn=24*60*60;
  let accessToken=jwt.sign({id: customer_id},SECRET_KEY,{
  expiresIn: expiresIn
  });
  let data = {access_token: accessToken};
  let query = conn.query(sql, data,(err,results) => {
    if(err){
res.status(400).send(JSON.stringify({"code":"USR_02","message":"The field example is empty","field":"example","status":"500"}));
}
if(!err){
    res.status(200).send({ "response": results, "data": data, "access_token": accessToken, "expiresIn": expiresIn});
}
  });
});
app.listen(3000,() =>{
console.log('Server started on port 3000...');
});
