﻿const express=require('express');
const bodyParser=require('body-parser');
const app=express();
const mysql=require('mysql');

app.use(bodyParser.json());
const conn=mysql.createConnection({
host: 'localhost',
user: 'root',
password: '',
database: 'shopping'
});

conn.connect((err) =>{
if(err) throw err;
console.log("You are connected to database!");
});
app.get('/attributes',(req,res)=>{
let sql="SELECT * FROM attributes";
let query=conn.query(sql,(err,results)=>{
if(err){
res.status(400).send(JSON.stringify({"code":"USR_02","message":"The field example is empty","field":"example"}));

}
else{
res.status(200).send(JSON.stringify(results));

}
});
});
app.get('/attributes/:attribute_id',(req,res)=>{
let sql="SELECT attribute_id,name FROM attributes WHERE attribute_id="+req.params.attribute_id;
let query=conn.query(sql,(err,results)=>{
if(err){
res.status(400).send(JSON.stringify({"code":"USR_02","message":"The field example is empty","field":"example"}));
}
else{
res.status(200).send(JSON.stringify(results));
}
});
});
app.get('/attributes/values/:attribute_id',(req,res)=>{
let sql="SELECT attribute_value_id,vl FROM vl WHERE attribute_id="+req.params.attribute_id;
let query=conn.query(sql,(err,results)=>{
if(err){
res.status(400).send(JSON.stringify({"code":"USR_02","message":"The field example is empty","field":"example"}));
}
else{
res.status(200).send(JSON.stringify(results));
}
});
});
app.get('/attributes/inProduct/:product_id',(req,res)=>{
let sql="SELECT a.name,v.attribute_value_id,v.vl FROM  attributes a,vl v WHERE v.product_id=a.product_id AND a.product_id="+req.params.product_id;
let query=conn.query(sql,(err,results)=>{
if(err){
res.status(400).send(JSON.stringify({"code":"USR_02","message":"The field example is empty","field":"example"}));
}
else{
res.status(200).send(JSON.stringify(results));
}
});
});

app.listen(3000,() =>{
console.log('Server started on port 3000...');
});
