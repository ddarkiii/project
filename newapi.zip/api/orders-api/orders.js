﻿const express=require('express');
const bodyParser=require('body-parser');
const app=express();
const mysql=require('mysql');

app.use(bodyParser.json());
const conn=mysql.createConnection({
host: 'localhost',
user: 'root',
password: '',
database: 'shopping'
});

conn.connect((err) =>{
if(err) throw err;
console.log("You are connected to database!");
});
//post orders
app.post('/orders',(req, res) => {
  let data = {cost_id: req.body.cost_id, product_id: req.body.product_id, tax_id: req.body.tax_id, attributes: req.body.attributes, product_name: req.body.product_name, quantity: req.body.quantity, unitcost: req.body.unitcost, subtotal: req.body.subtotal, shipping_id: req.body.shipping_id};
  let sql = "INSERT INTO orders SET ?";
  let query = conn.query(sql, data,(err, results) => {
if(err){
res.status(400).send(JSON.stringify({"code":"USR_02","message":"The field example is empty","field":"example","status":"500"}));
res.status(401).send(JSON.stringify({"code":"AUT-02","message":"The API is invalid.","field":"API-KEY"}));
}	
else{
    res.send(JSON.stringify({"status": 200, "error": null, "response": results}));
}
  });
});
//get orders with orderid
app.get('/orders/:orderId',(req,res)=>{
let sql="SELECT * FROM orders WHERE orderId="+req.params.orderId;
let query=conn.query(sql,(err,results)=>{
if(err){
res.status(400).send(JSON.stringify({"code":"USR_02","message":"The field example is empty","field":"example","status":"500"}));
res.status(401).send(JSON.stringify({"code":"AUT-02","message":"The apikey is invalid.","field":"API_KEY"}));
res.status(404).send(JSON.stringify({"message":"Endpoint not found."}));
}
if(!err){
res.status(200).send(JSON.stringify(results));
}
});
});
//Get shortDetail in orders
app.get('/orders/shortDetail/:order_id',(req,res)=>{
let sql="SELECT * FROM orders_shortdetail WHERE order_id="+req.params.order_id;
let query=conn.query(sql,(err,results)=>{
if(err){
res.status(400).send(JSON.stringify({"code":"USR_02","message":"The field example is empty","field":"example","status":"500"}));
res.status(401).send(JSON.stringify({"code":"AUT-02","message":"The apikey is invalid.","field":"API_KEY"}));
}
if(!err){
res.status(200).send(JSON.stringify(results));
}
});
});
app.get('/orders/inCustomer/:customer_id',(req,res)=>{
let sql="SELECT * FROM orders WHERE customer_id="+req.params.customer_id;
let query=conn.query(sql,(err,results)=>{
if(err){
res.status(400).send(JSON.stringify({"code":"USR_02","message":"The field example is empty","field":"example","status":"500"}));
res.status(401).send(JSON.stringify({"code":"AUT-02","message":"The apikey is invalid.","field":"API_KEY"}));
}
if(!err){
res.status(200).send(JSON.stringify(results));
}
});
});
app.listen(3000,() =>{
console.log('Server started on port 3000...');
});
