﻿const express=require('express');
const bodyParser=require('body-parser');
const app=express();
const mysql=require('mysql');

app.use(bodyParser.json());
const conn=mysql.createConnection({
host: 'localhost',
user: 'root',
password: '',
database: 'shopping'
});

conn.connect((err) =>{
if(err) throw err;
console.log("You are connected to database!");
});
app.get('/products',(req,res)=>{
let sql="SELECT count(page) as count,product_id,name,description,price,discounted_price,thrumbail FROM products LIMIT 20";
let query=conn.query(sql,(err,results)=>{
if(err){
res.status(400).send(JSON.stringify({"code":"USR_02","message":"The field example is empty","field":"example","status":"500"}));

}
else{
	let total=results[0].count;
res.status(200).send(JSON.stringify({"count":total,"rows":results}));

}
});
});

app.get('/products/search',(req,res)=>{
	
let sql="SELECT product_id,name FROM products WHERE name="+req.query.name +"LIMIT 20";
let query=conn.query(sql,(err,results)=>{
if(err){
res.status(400).send(JSON.stringify({"code":"USR_02","message":"The field example is empty","field":"example","status":"500"}));
}
else{
res.status(200).send(JSON.stringify(results));
}
});
});

app.get('/products/:product_id',(req,res)=>{
let sql="SELECT product_id,name,description,price,discounted_price,image,image2,thrumbail,display FROM products WHERE product_id="+req.params.product_id;
let query=conn.query(sql,(err,results)=>{
if(err){
res.status(400).send(JSON.stringify({"code":"USR_02","message":"The field example is empty","field":"example","status":"500"}));
}
else{
res.status(200).send(JSON.stringify(results));
}
});
});
app.get('/products/inDepartment/:department_id',(req,res)=>{
let sql="SELECT p.product_id,p.name,p.description,p.price,p.discounted_price,p.thrumbail,p.image,p.image2,p.display,d.department_id,d.name,d.description FROM products p,departments d WHERE p.department_id="+req.params.department_id;
let query=conn.query(sql,(err,results)=>{
if(err){
res.status(400).send(JSON.stringify({"code":"USR_02","message":"The field example is empty","field":"example","status":"500"}));
}
else{
res.status(200).send(JSON.stringify(results));
}
});
});

app.get('/products/:product_id/details',(req,res)=>{
let sql="SELECT product_id,name,description,price,discounted_price,image,image2 FROM products WHERE product_id="+req.params.product_id;
let query=conn.query(sql,(err,results)=>{
if(err){
res.status(400).send(JSON.stringify({"code":"USR_02","message":"The field example is empty","field":"example","status":"500"}));
}
else{
res.status(200).send(JSON.stringify(results));
}
});
});
app.get('/products/inCategory/:category_id',(req,res)=>{
let sql="SELECT product_id,name,description,price,discounted_price,image,image2 FROM products WHERE category_id="+req.params.category_id;
let query=conn.query(sql,(err,results)=>{
if(err){
res.status(400).send(JSON.stringify({"code":"USR_02","message":"The field example is empty","field":"example","status":"500"}));
}
else{
res.status(200).send(JSON.stringify(results));
}
});
});
app.get('/products/:product_id/locations',(req,res)=>{
let sql="SELECT c.category_id,c.name as category_name,d.department_id,d.name as department_name FROM category c,departments d WHERE c.product_id=d.product_id AND d.product_id="+req.params.product_id;
let query=conn.query(sql,(err,results)=>{
if(err){
res.status(400).send(JSON.stringify({"code":"USR_02","message":"The field example is empty","field":"example","status":"500"}));
}
else{
res.status(200).send(JSON.stringify(results));
}
});
});

app.get('/products/:product_id/review',(req,res)=>{
let sql="SELECT review_id,name,review,rating,created_on FROM review WHERE product_id="+req.params.product_id;
let query=conn.query(sql,(err,results)=>{
if(err){
res.status(400).send(JSON.stringify({"code":"USR_02","message":"The field example is empty","field":"example","status":"500"}));
}
else{
res.status(200).send(JSON.stringify(results));
}
});
});
//add new review in product
app.post('/products/product_id/reviews',(req, res) => {
  let data = {product_id: req.body.product_id, name: req.body.name, review: req.body.review, rating: req.body.rating, created_on: req.body.created_on};
  let sql = "INSERT INTO review SET ?";
  let query = conn.query(sql, data,(err, results) => {
if(err){
res.status(400).send(JSON.stringify({"code":"USR_02","message":"The field example is empty","field":"example","status":"500"}));
res.status(401).send(JSON.stringify({"code":"AUT-02","message":"The API is invalid.","field":"API-KEY"}));
}	
else{
    res.send(JSON.stringify({"status": 200, "error": null, "response": results}));
}
  });
});
app.listen(3000,() =>{
console.log('Server started on port 3000...');
});
