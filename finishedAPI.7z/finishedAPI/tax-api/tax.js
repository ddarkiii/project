﻿const express=require('express');
const bodyParser=require('body-parser');
const app=express();
const mysql=require('mysql');

//connect to database
app.use(bodyParser.json());
const conn=mysql.createConnection({
host: 'localhost',
user: 'root',
password: '',
database: 'shopping'
});

conn.connect((err) =>{
if(err) throw err;
console.log("You are connected to database!");
});
//show all tax
app.get('/tax',(req,res)=>{
let sql="SELECT * FROM tax";
let query=conn.query(sql,(err,results)=>{
if(err){
res.status(400).send(JSON.stringify({"code":"USR_02","message":"The field example is empty","field":"example"}));

}
else{
res.status(200).send(JSON.stringify(results));
}
});
});
//show single tax
app.get('/tax/:tax_id',(req,res)=>{
let sql="SELECT * FROM tax WHERE tax_id="+req.params.tax_id;
let query=conn.query(sql,(err,results)=>{
if(err){
res.status(400).send(JSON.stringify({"code":"USR_02","message":"The field example is empty","field":"example"}));
}
else{
res.status(200).send(JSON.stringify(results));
}
});
});
app.listen(3000,() =>{
console.log('Server started on port 3000...');
});
